import { P as o } from "./main-qizrsdxz.js";
class g {
  logger;
  onError;
  constructor(r) {
    this.logger = r.logger, this.onError = r.onError;
  }
  handleError(r) {
    r instanceof o ? this.logger.error(r.message, r.details) : r instanceof Error ? this.logger.error(r.message, r) : this.logger.error("Unknown error", r), this.onError?.(r);
  }
  setErrorCallback(r) {
    this.logger.debug("Setting custom error callback"), this.onError = r;
  }
}
export {
  g as ErrorHandlingService
};
