import { l as a } from "./main-qizrsdxz.js";
class c {
  debugService;
  apiUrl = "";
  referenceSystem = "";
  context = {};
  setApiUrl(e) {
    this.apiUrl = e;
  }
  setReferenceSystem(e) {
    this.referenceSystem = e;
  }
  setContext(e) {
    this.context = e;
  }
  async initDebugService(e) {
    const t = await this.logger(), r = await this.storage(), { DebugService: i } = await import("./debug-service-DX9Fv8JG.js");
    this.debugService = new i({
      logger: t,
      storageService: r,
      developerModeSettings: e
    });
  }
  logger = a(async () => {
    const { LoggerService: e } = await import("./logger-service-CY6PdnVF.js");
    return new e("Pixel SDK");
  });
  errorHandling = a(async () => {
    const e = await this.logger(), { ErrorHandlingService: t } = await import("./error-handling-service-BZtVa53d.js");
    return new t({ logger: e });
  });
  storage = a(async () => {
    const e = await this.logger(), { StorageService: t } = await import("./storage-service-C3akGEyb.js");
    return new t({ logger: e });
  });
  window = a(async () => {
    const e = await this.logger(), t = await this.errorHandling(), r = await this.storage(), { WindowService: i } = await import("./window-service-Bip1-Xzq.js");
    return new i({
      logger: e,
      errorHandlingService: t,
      storageService: r
    });
  });
  user = a(async () => {
    const e = await this.logger(), t = await this.storage(), { UserService: r } = await import("./user-service-B5PzfKgO.js"), i = new r({
      logger: e,
      storageService: t,
      debugService: this.debugService,
      intuitContext: this.context
    });
    return (await this.window()).onPageChange(i.onPageChanged.bind(i)), i;
  });
  asyncStorage = a(async () => {
    const e = await this.logger(), { AsyncStorageService: t } = await import("./async-storage-service-C0qoizHv.js");
    return new t({ logger: e });
  });
  track = a(async () => {
    const e = await this.logger(), t = await this.errorHandling(), r = await this.user(), i = await this.asyncStorage(), { TrackService: n } = await import("./track-service-f2oJLvDt.js");
    return new n({
      logger: e,
      errorHandlingService: t,
      debugService: this.debugService,
      asyncStorageService: i,
      userService: r,
      apiUrl: this.apiUrl,
      referenceSystem: this.referenceSystem,
      context: this.context
    });
  });
  shopify = a(async () => {
    const e = await this.logger(), t = await this.user(), { ShopifyService: r } = await import("./shopify-service-Dk_KSGCl.js");
    return new r({
      logger: e,
      userService: t,
      trackUrl: this.apiUrl + "/v1/track"
    });
  });
  wix = a(async () => {
    const e = await this.logger(), t = await this.errorHandling(), r = await this.user(), i = await this.track(), { WixService: n } = await import("./wix-service-CHJAFPwS.js");
    return new n({
      logger: e,
      errorHandlingService: t,
      userService: r,
      trackService: i
    });
  });
}
export {
  c as ServiceManager
};
