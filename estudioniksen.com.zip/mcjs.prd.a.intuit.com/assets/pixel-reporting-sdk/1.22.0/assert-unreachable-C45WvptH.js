import { U as r } from "./main-qizrsdxz.js";
const o = (a) => {
  throw new r();
};
export {
  o as a
};
