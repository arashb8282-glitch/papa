const s = ["error", "warn", "info", "debug"];
class a {
  loggerName;
  logLevel;
  constructor(e, o = "warn") {
    this.loggerName = e, this.logLevel = o;
  }
  error(e, ...o) {
    this.shouldLog("error") && console.error(...this.formatMessage("error", e), ...o);
  }
  warn(e, ...o) {
    this.shouldLog("warn") && console.warn(...this.formatMessage("warn", e), ...o);
  }
  info(e, ...o) {
    this.shouldLog("info") && console.info(...this.formatMessage("info", e), ...o);
  }
  debug(e, ...o) {
    this.shouldLog("debug") && console.debug(...this.formatMessage("debug", e), ...o);
  }
  setLogLevel(e) {
    this.logLevel = e;
  }
  shouldLog(e) {
    return s.indexOf(e) <= s.indexOf(this.logLevel);
  }
  formatMessage(e, o) {
    const i = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
      hour12: !1,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      fractionalSecondDigits: 3,
      timeZoneName: "short"
    });
    let r, t;
    switch (e) {
      case "error":
        r = "ERROR", t = "red";
        break;
      case "warn":
        r = " WARN", t = "orange";
        break;
      case "info":
        r = " INFO", t = "lightgreen";
        break;
      case "debug":
        r = "DEBUG", t = "teal";
        break;
    }
    return [
      `%c${i} %c${this.loggerName} %c${r} %c${o}`,
      "color: gray",
      "color: magenta; font-weight: bold",
      `color: ${t}; font-weight: bold`,
      "color: inherit"
    ];
  }
}
export {
  a as LoggerService
};
