class o {
  logger;
  userService;
  trackUrl;
  constructor(i) {
    this.logger = i.logger, this.userService = i.userService, this.trackUrl = i.trackUrl, this.logger.debug("ShopifyService initialized");
  }
  /**
   * Initialize the Shopify integration by publishing the ready event
   * with context and identifiers for the Shopify app pixel.
   */
  init() {
    const i = this.userService.getContext(void 0, "SHOPIFY"), e = this.userService.getC2Identifiers();
    this.logger.debug("Publishing mailchimp-pixel:ready event", {
      context: i,
      c2Identifiers: e
    }), this.waitForShopify().then(() => {
      window.Shopify.analytics.publish("mailchimp-pixel:ready", {
        pixelApiURL: this.trackUrl,
        context: i,
        c2Identifiers: e
      });
    }).catch((t) => {
      this.logger.error("Error waiting for Shopify", t);
    }), window.localStorage.setItem(
      "mailchimp-pixel:context",
      JSON.stringify({
        pixelApiURL: this.trackUrl,
        context: i,
        c2Identifiers: e
      })
    ), this.logger.info("Shopify integration initialized");
  }
  async waitForShopify() {
    return new Promise((i) => {
      const e = setInterval(() => {
        typeof window.Shopify < "u" && (clearInterval(e), i());
      }, 500);
    });
  }
}
export {
  o as ShopifyService
};
