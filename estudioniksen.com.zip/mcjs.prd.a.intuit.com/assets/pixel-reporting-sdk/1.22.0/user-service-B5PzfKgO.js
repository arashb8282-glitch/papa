const a = {
  PIXEL_VISITOR_ID: "PIXEL_VISITOR_ID"
};
class l {
  logger;
  storageService;
  userData;
  sessionData;
  isNewVisitor = !1;
  isNewSession = !1;
  INACTIVITY_TIMEOUT = 1800 * 1e3;
  // 30 minutes
  lastInteractionTs;
  intuitContext;
  constructor(e) {
    e.logger.debug("UserService initializing", e), this.logger = e.logger, this.storageService = e.storageService, this.userData = this.initializeUserData(), this.sessionData = this.initializeSessionData(e.debugService?.shouldForceNewSession()), this.lastInteractionTs = Date.now(), this.intuitContext = e.intuitContext, this.logger.debug("UserService initialized", { userData: this.userData, sessionData: this.sessionData });
  }
  onPageChanged() {
    const e = Date.now();
    e - this.lastInteractionTs > this.INACTIVITY_TIMEOUT && (this.logger.debug("Starting new session due to inactivity"), this.sessionData = this.initializeSessionData(!0)), this.lastInteractionTs = e;
  }
  initializeUserData() {
    const e = this.storageService.get("userData");
    e?.anonymousId || (this.isNewVisitor = !0, this.logger.debug("New visitor detected"));
    const i = e?.anonymousId ?? crypto.randomUUID(), t = e?.anonymousTs ?? Date.now(), s = { anonymousId: i, anonymousTs: t };
    return this.storageService.set("userData", s), s;
  }
  initializeSessionData(e) {
    let i, t, s, r;
    if (e)
      this.isNewSession = !0, i = crypto.randomUUID(), t = Date.now(), s = window.location.href, r = document.referrer, this.logger.debug("New session started (forced)");
    else {
      const n = this.storageService.get("sessionData");
      n?.sessionId ? (i = n.sessionId, t = n.sessionTs, s = n.originalURL, r = n.originalReferrer) : (this.isNewSession = !0, i = crypto.randomUUID(), t = Date.now(), s = window.location.href, r = document.referrer, this.logger.debug("New session started"));
    }
    const o = { sessionId: i, sessionTs: t, originalURL: s, originalReferrer: r };
    return this.storageService.set("sessionData", o), o;
  }
  /**
   * Returns the current context containing session and browser information.
   * This is used to pass context to external pixels (e.g., Shopify app pixel).
   */
  getContext(e, i) {
    return {
      referenceSystem: e?.referenceSystem ?? i ?? "SHOPIFY",
      session: {
        sessionId: e?.session?.sessionId ?? this.sessionData.sessionId,
        originalLandingPage: e?.session?.originalLandingPage ?? this.sessionData.originalURL,
        originalReferrer: e?.session?.originalReferrer ?? this.sessionData.originalReferrer
      },
      browser: {
        url: e?.browser?.url ?? window.location.href,
        pageTitle: e?.browser?.pageTitle ?? document.title,
        referrer: e?.browser?.referrer ?? document.referrer,
        screen: {
          width: e?.browser?.screen?.width ?? window.innerWidth,
          height: e?.browser?.screen?.height ?? window.innerHeight
        },
        isMultitouchDevice: e?.browser?.isMultitouchDevice ?? navigator.maxTouchPoints > 1
      },
      intuit: e?.intuit ?? this.intuitContext
    };
  }
  getPixelVisitorIdentifier() {
    return {
      id: this.userData.anonymousId,
      identifierType: a.PIXEL_VISITOR_ID
    };
  }
  /**
   * Returns the c2Identifiers array containing the pixel visitor ID.
   * This is used to pass identifiers to external pixels (e.g., Shopify app pixel).
   */
  getC2Identifiers() {
    return [this.getPixelVisitorIdentifier()];
  }
}
export {
  a as IdentifierType,
  l as UserService
};
