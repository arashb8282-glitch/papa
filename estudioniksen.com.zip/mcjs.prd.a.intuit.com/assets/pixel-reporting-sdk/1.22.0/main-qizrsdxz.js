const g = (a) => {
  let e, r;
  return () => e ? Promise.resolve(e) : r || (r = a().then((t) => (e = t, t)), r);
};
class d extends Error {
  details;
  constructor(e, r = {
    service: "Unknown"
  }) {
    super(e), this.name = new.target.name, this.details = r;
  }
}
class S extends d {
  constructor() {
    super("Unreachable code reached");
  }
}
class v extends d {
  constructor() {
    super("Pixel not initialized", {
      service: "Pixel"
    });
  }
}
class w extends d {
  constructor(e) {
    super("Error setting storage item", {
      service: "StorageService",
      ...e
    });
  }
}
class f extends d {
  constructor(e) {
    super("Event failed to send", {
      service: "TrackService",
      ...e
    });
  }
}
class E extends d {
  constructor() {
    super("IndexedDB is not available", {
      service: "AsyncStorageService"
    });
  }
}
class u extends d {
  constructor(e) {
    super("AsyncStorage operation failed", {
      service: "AsyncStorageService",
      ...e
    });
  }
}
class c {
  static initialized = !1;
  async init(e) {
    const r = await this.services(), t = await r.errorHandling();
    try {
      const i = await r.logger();
      if (c.initialized && i.warn("SDK is already initialized. Overriding existing context."), r.setApiUrl(e.apiUrl), e.referenceSystem && r.setReferenceSystem(e.referenceSystem), e.context && r.setContext(e.context), e.onError && t.setErrorCallback(e.onError), c.initialized)
        return;
      c.initialized = !0;
      const s = await r.storage();
      (e.developerMode || s.get("developerModeEnabled")) && await r.initDebugService(e.developerModeSettings), i.debug("Initializing", e);
      const n = await r.window();
      e.autoTrack && (n.hasPageLoaded() ? await this.track("PAGE_VIEWED", {}) : n.onPageLoad(async () => {
        await this.track("PAGE_VIEWED", {});
      }), n.onPageChange(async () => {
        await this.track("PAGE_VIEWED", {});
      })), e.referenceSystem === "SHOPIFY" && (await r.shopify()).init(), i.info("Initialization complete", e.context ?? {});
    } catch (i) {
      t.handleError(i);
    }
  }
  async track(e, r, t, i) {
    const s = await this.services(), n = await s.errorHandling();
    try {
      if (!c.initialized)
        throw new v();
      await (await s.track()).track(e, r, t, i);
    } catch (l) {
      n.handleError(l);
    }
  }
  async identify({
    type: e,
    value: r,
    debugContextOverrides: t
  }) {
    const i = await this.services(), s = await i.errorHandling();
    try {
      if (!c.initialized)
        throw new v();
      await (await i.track()).identify(e, r, t);
    } catch (n) {
      s.handleError(n);
    }
  }
  services = g(async () => {
    const { ServiceManager: e } = await import("./service-manager-BvDqRaBd.js");
    return new e();
  });
}
const o = new c(), y = {
  init: o.init.bind(o),
  track: o.track.bind(o),
  identify: o.identify.bind(o)
};
export {
  u as A,
  f as E,
  E as I,
  d as P,
  w as S,
  S as U,
  v as a,
  g as l,
  y as p
};
