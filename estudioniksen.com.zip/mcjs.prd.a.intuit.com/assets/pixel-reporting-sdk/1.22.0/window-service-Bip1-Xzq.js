class i {
  logger;
  errorHandlingService;
  URL_CHANGE_CHECK_INTERVAL = 1e3;
  // 1 second
  lastKnownUrl = window.location.href;
  pageChangeListeners = [];
  constructor(e) {
    e.logger.debug("WindowService initializing", e), this.logger = e.logger, this.errorHandlingService = e.errorHandlingService, window.IntuitPixel = {
      enableDeveloperMode: (r) => {
        e.storageService.set("developerModeEnabled", !0), r ? e.storageService.set("developerModeSettings", r) : e.storageService.unset("developerModeSettings");
      },
      disableDeveloperMode: () => {
        e.storageService.unset("developerModeEnabled"), e.storageService.unset("developerModeSettings");
      },
      setDeveloperModeSettings: (r) => {
        e.storageService.set("developerModeSettings", r);
      }
    }, setInterval(this.checkURLChange.bind(this), this.URL_CHANGE_CHECK_INTERVAL), this.logger.debug("WindowService initialized");
  }
  hasPageLoaded() {
    return document.readyState === "complete" || document.readyState === "interactive";
  }
  onPageLoad(e) {
    const r = async () => {
      try {
        await e();
      } catch (t) {
        this.errorHandlingService.handleError(t);
      }
    };
    window.addEventListener("DOMContentLoaded", () => {
      r();
    });
  }
  onPageChange(e) {
    const r = async () => {
      try {
        await e();
      } catch (t) {
        this.errorHandlingService.handleError(t);
      }
    };
    this.pageChangeListeners.push(r);
  }
  checkURLChange() {
    this.lastKnownUrl !== window.location.href && (this.logger.debug("URL change detected", { from: this.lastKnownUrl, to: window.location.href }), this.pageChangeListeners.forEach((e) => {
      e();
    }), this.lastKnownUrl = window.location.href);
  }
}
export {
  i as WindowService
};
