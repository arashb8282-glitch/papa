import { S as i } from "./main-qizrsdxz.js";
import { a } from "./assert-unreachable-C45WvptH.js";
const o = {
  userData: { key: "user_data", location: "local-storage" },
  sessionData: { key: "session_data", location: "session-storage" },
  developerModeEnabled: { key: "developer_mode_enabled", location: "local-storage" },
  developerModeSettings: { key: "developer_mode_settings", location: "local-storage" }
};
class n {
  logger;
  STORAGE_KEY_PREFIX = "intuit_pixel_sdk_";
  constructor(e) {
    this.logger = e.logger;
  }
  get(e) {
    const t = this.STORAGE_KEY_PREFIX + o[e].key;
    let s;
    switch (o[e].location) {
      case "session-storage":
        s = sessionStorage.getItem(t) ?? void 0;
        break;
      case "local-storage":
        s = localStorage.getItem(t) ?? void 0;
        break;
      default:
        a(o[e].location);
    }
    return s ? JSON.parse(s) : void 0;
  }
  set(e, t) {
    const s = this.STORAGE_KEY_PREFIX + o[e].key;
    this.logger.debug("Setting storage item", { key: e, location: o[e].location, value: t });
    try {
      switch (o[e].location) {
        case "session-storage":
          sessionStorage.setItem(s, JSON.stringify(t));
          break;
        case "local-storage":
          localStorage.setItem(s, JSON.stringify(t));
          break;
        default:
          a(o[e].location);
      }
    } catch (r) {
      throw new i({
        key: e,
        value: t,
        storageLocation: o[e].location,
        originalError: r
      });
    }
  }
  unset(e) {
    const t = this.STORAGE_KEY_PREFIX + o[e].key;
    switch (this.logger.debug("Removing storage item", { key: e, location: o[e].location }), o[e].location) {
      case "session-storage":
        sessionStorage.removeItem(t);
        break;
      case "local-storage":
        localStorage.removeItem(t);
        break;
      default:
        a(o[e].location);
    }
  }
}
export {
  n as StorageService
};
