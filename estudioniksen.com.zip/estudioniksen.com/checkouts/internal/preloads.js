
    (function() {
      var preconnectOrigins = ["https://cdn.shopify.com"];
      var scripts = ["/cdn/shopifycloud/checkout-web/assets/c1/polyfills.CZ0dCDgn.js","/cdn/shopifycloud/checkout-web/assets/c1/app.CCnTwoHi.js","/cdn/shopifycloud/checkout-web/assets/c1/630ba094.D6Cf0_XP.js","/cdn/shopifycloud/checkout-web/assets/c1/4509beb0.R3_-EHgf.js","/cdn/shopifycloud/checkout-web/assets/c1/6a2fc6d6.oFWtb6Dn.js","/cdn/shopifycloud/checkout-web/assets/c1/f025431a.BlsbPO0-.js","/cdn/shopifycloud/checkout-web/assets/c1/6ec9a0fa.CWlvtqPe.js","/cdn/shopifycloud/checkout-web/assets/c1/164ad2e3.E0GVZGJ2.js","/cdn/shopifycloud/checkout-web/assets/c1/fb3b4968.CFSMxxZI.js","/cdn/shopifycloud/checkout-web/assets/c1/7d6bf786.B_fvsszI.js","/cdn/shopifycloud/checkout-web/assets/c1/0f5b1987.DE6aAVVA.js","/cdn/shopifycloud/checkout-web/assets/c1/9e5d8eb8.LM7m9FaB.js","/cdn/shopifycloud/checkout-web/assets/c1/a45fed45.Bv40l-5Y.js","/cdn/shopifycloud/checkout-web/assets/c1/c328865d.Bj11LM-n.js","/cdn/shopifycloud/checkout-web/assets/c1/f1384cc2.BX1JbjgR.js","/cdn/shopifycloud/checkout-web/assets/c1/4618373b.DVq4pLjg.js","/cdn/shopifycloud/checkout-web/assets/c1/486c3fda.Cfnojchm.js","/cdn/shopifycloud/checkout-web/assets/c1/17f6d6d8.DuiECjdC.js","/cdn/shopifycloud/checkout-web/assets/c1/19286c78.C9rnsRZ_.js","/cdn/shopifycloud/checkout-web/assets/c1/c7b92b97.Bj1OtDBh.js","/cdn/shopifycloud/checkout-web/assets/c1/faece749.Cu4PDu4n.js","/cdn/shopifycloud/checkout-web/assets/c1/77d9e668.Cq4EgqAT.js","/cdn/shopifycloud/checkout-web/assets/c1/2c7267bc.COXwVabN.js","/cdn/shopifycloud/checkout-web/assets/c1/4661cd61.DMQc-N9Y.js","/cdn/shopifycloud/checkout-web/assets/c1/928dbd30.BYImMXwZ.js","/cdn/shopifycloud/checkout-web/assets/c1/77821758.CIHBOvKY.js","/cdn/shopifycloud/checkout-web/assets/c1/82d59f8f.DjjnJvTu.js","/cdn/shopifycloud/checkout-web/assets/c1/08e2c58d.C8TaLsPv.js","/cdn/shopifycloud/checkout-web/assets/c1/a8202753.uxxMblPb.js","/cdn/shopifycloud/checkout-web/assets/c1/dfb65aab.3qwjGqDt.js","/cdn/shopifycloud/checkout-web/assets/c1/e1177f6f.B3S-yLcL.js","/cdn/shopifycloud/checkout-web/assets/c1/2f5db8a5.DhZRjPTT.js","/cdn/shopifycloud/checkout-web/assets/c1/c0466e46.C0ApXsTP.js","/cdn/shopifycloud/checkout-web/assets/c1/8d7e1337.D1SAQfdV.js","/cdn/shopifycloud/checkout-web/assets/c1/5bf177e7.DMVtkD1Z.js","/cdn/shopifycloud/checkout-web/assets/c1/f3089cd3.DFPD_hLQ.js","/cdn/shopifycloud/checkout-web/assets/c1/8da28279.CTDG9Msf.js","/cdn/shopifycloud/checkout-web/assets/c1/a541bc81.BbSwjfQ7.js","/cdn/shopifycloud/checkout-web/assets/c1/6b0dea54.BLDw0fAB.js","/cdn/shopifycloud/checkout-web/assets/c1/9c33421f.BTRXzV0a.js","/cdn/shopifycloud/checkout-web/assets/c1/37c3ef79.Vp4-YRRU.js","/cdn/shopifycloud/checkout-web/assets/c1/651bb548.DGT3CLEP.js","/cdn/shopifycloud/checkout-web/assets/c1/83f74304.ByEA9Ea5.js","/cdn/shopifycloud/checkout-web/assets/c1/7edfee1d.DQeLCmju.js","/cdn/shopifycloud/checkout-web/assets/c1/ce604576.DRj3vMAG.js","/cdn/shopifycloud/checkout-web/assets/c1/b01c110b.DOCI-0ET.js","/cdn/shopifycloud/checkout-web/assets/c1/4e32eceb.Brd5q1On.js","/cdn/shopifycloud/checkout-web/assets/c1/f00fed33.CL2GPWdk.js","/cdn/shopifycloud/checkout-web/assets/c1/94493b3a.CCW-L3k9.js","/cdn/shopifycloud/checkout-web/assets/c1/99cd9b25.3399VuSv.js","/cdn/shopifycloud/checkout-web/assets/c1/676eb8e9.DibWorRY.js","/cdn/shopifycloud/checkout-web/assets/c1/a9ee22a0.BVvCzjoh.js","/cdn/shopifycloud/checkout-web/assets/c1/56132226.DDRFSq_E.js","/cdn/shopifycloud/checkout-web/assets/c1/0e3247a0.HLCZI8ps.js","/cdn/shopifycloud/checkout-web/assets/c1/1dbf806c.DdAI_xrP.js","/cdn/shopifycloud/checkout-web/assets/c1/a56386a6.tbnPL4NL.js","/cdn/shopifycloud/checkout-web/assets/c1/674595ba.Bz7cFuVL.js","/cdn/shopifycloud/checkout-web/assets/c1/173d1fdf._p3lDHKs.js","/cdn/shopifycloud/checkout-web/assets/c1/0d85278a.CZC8pjYT.js","/cdn/shopifycloud/checkout-web/assets/c1/16138b9e.kpONL6Yy.js","/cdn/shopifycloud/checkout-web/assets/c1/55432860.B_6ZLhb6.js","/cdn/shopifycloud/checkout-web/assets/c1/0be192b6.BKgdMqHN.js","/cdn/shopifycloud/checkout-web/assets/c1/2bce9289.D9vULkO0.js","/cdn/shopifycloud/checkout-web/assets/c1/62a11d3e.dfpVjuLH.js","/cdn/shopifycloud/checkout-web/assets/c1/9a493f3d.Bsxs3agT.js","/cdn/shopifycloud/checkout-web/assets/c1/402b40d8.Dc6Zrl0N.js","/cdn/shopifycloud/checkout-web/assets/c1/17db3e71.NZeQ17rm.js","/cdn/shopifycloud/checkout-web/assets/c1/b4f06cd6.CwW_AIzI.js","/cdn/shopifycloud/checkout-web/assets/c1/2b0d1656.RNKZGKow.js","/cdn/shopifycloud/checkout-web/assets/c1/64c3067d.CC4L6z6C.js","/cdn/shopifycloud/checkout-web/assets/c1/bbe16958.Dr4AmJqi.js","/cdn/shopifycloud/checkout-web/assets/c1/6a8181a5.BwEEwxa0.js","/cdn/shopifycloud/checkout-web/assets/c1/4205169c.CJ63uDfv.js","/cdn/shopifycloud/checkout-web/assets/c1/1befea5c.B7tczeHF.js","/cdn/shopifycloud/checkout-web/assets/c1/ff52cf6d.C-_S3LI1.js","/cdn/shopifycloud/checkout-web/assets/c1/74e5a557.i4pBuM37.js","/cdn/shopifycloud/checkout-web/assets/c1/f4d0afee.CBQgxqHw.js","/cdn/shopifycloud/checkout-web/assets/c1/0b704646.DY0usYzF.js","/cdn/shopifycloud/checkout-web/assets/c1/a7ef2c81.BU2z5bNe.js","/cdn/shopifycloud/checkout-web/assets/c1/f0b3b291.B_L97_yO.js","/cdn/shopifycloud/checkout-web/assets/c1/114cc9d1.C_JEseqR.js","/cdn/shopifycloud/checkout-web/assets/c1/e7ae9e74.CrXZS79N.js","/cdn/shopifycloud/checkout-web/assets/c1/91e796b6.CV4ogUp0.js","/cdn/shopifycloud/checkout-web/assets/c1/a222330e.CLLxVTlv.js","/cdn/shopifycloud/checkout-web/assets/c1/c380a132.vzFIcUb-.js","/cdn/shopifycloud/checkout-web/assets/c1/3839d836.DPyxB-_S.js","/cdn/shopifycloud/checkout-web/assets/c1/72fde58e.BzEqcXFl.js","/cdn/shopifycloud/checkout-web/assets/c1/8cad6ded.DfyFpH4e.js","/cdn/shopifycloud/checkout-web/assets/c1/9e556116.DJqOE6yL.js","/cdn/shopifycloud/checkout-web/assets/c1/abf134e3.B3AIEhlZ.js","/cdn/shopifycloud/checkout-web/assets/c1/e6a05f36.U3p3UDX-.js","/cdn/shopifycloud/checkout-web/assets/c1/8e6bd8e5.BKLEQ7DX.js","/cdn/shopifycloud/checkout-web/assets/c1/a012ee00.CTY4L_qv.js","/cdn/shopifycloud/checkout-web/assets/c1/71b36506.zT54HwTR.js","/cdn/shopifycloud/checkout-web/assets/c1/7aefefff.f3e2qC8e.js","/cdn/shopifycloud/checkout-web/assets/c1/e72406f8.BbkwWI6o.js","/cdn/shopifycloud/checkout-web/assets/c1/bdb60128.0FzQsBK4.js","/cdn/shopifycloud/checkout-web/assets/c1/a0df1226.xjNo4qER.js","/cdn/shopifycloud/checkout-web/assets/c1/8efef14b.DyOdR0xl.js","/cdn/shopifycloud/checkout-web/assets/c1/c1adaf81.Cx57sSL5.js","/cdn/shopifycloud/checkout-web/assets/c1/21162507.ZBi71-Xy.js","/cdn/shopifycloud/checkout-web/assets/c1/139f607b.CcdwL0Ch.js","/cdn/shopifycloud/checkout-web/assets/c1/5f1fce8b.e4QsuNYD.js","/cdn/shopifycloud/checkout-web/assets/c1/bace9a08.CfvROCy0.js","/cdn/shopifycloud/checkout-web/assets/c1/8e2be3f2.CPWJAc23.js","/cdn/shopifycloud/checkout-web/assets/c1/2d034bf2.zkV7XcW3.js","/cdn/shopifycloud/checkout-web/assets/c1/972590c9.CpJmBxDc.js","/cdn/shopifycloud/checkout-web/assets/c1/9961965b.BoHJbW0r.js","/cdn/shopifycloud/checkout-web/assets/c1/bc751930.Dh3XXtum.js","/cdn/shopifycloud/checkout-web/assets/c1/842452fd.CAxnNKmH.js","/cdn/shopifycloud/checkout-web/assets/c1/a70a5b74.muNzEuba.js","/cdn/shopifycloud/checkout-web/assets/c1/b068efe0.CHTHZx12.js","/cdn/shopifycloud/checkout-web/assets/c1/2692118b.4T7IbnKZ.js","/cdn/shopifycloud/checkout-web/assets/c1/c4303b96.DfiIlsSH.js","/cdn/shopifycloud/checkout-web/assets/c1/7ee3a05c.DJrjRjGv.js","/cdn/shopifycloud/checkout-web/assets/c1/0d8691fc.Df4fnyBb.js","/cdn/shopifycloud/checkout-web/assets/c1/b0923a20.aQUw6dDJ.js","/cdn/shopifycloud/checkout-web/assets/c1/7e9c6d7c.DUZ1PIGz.js","/cdn/shopifycloud/checkout-web/assets/c1/ea392d18.CtzWripj.js","/cdn/shopifycloud/checkout-web/assets/c1/b2ef26e8.DIisfXRs.js","/cdn/shopifycloud/checkout-web/assets/c1/99bfe9cf.Bjs0CvRV.js","/cdn/shopifycloud/checkout-web/assets/c1/1493337c.B9PEl7H4.js","/cdn/shopifycloud/checkout-web/assets/c1/3c46c6f5.CBX3RMNX.js","/cdn/shopifycloud/checkout-web/assets/c1/e29daa9a.fhitJGWR.js","/cdn/shopifycloud/checkout-web/assets/c1/b2371320.-trHoLYt.js","/cdn/shopifycloud/checkout-web/assets/c1/a735741f.Hd23h4fQ.js","/cdn/shopifycloud/checkout-web/assets/c1/5a1effbb.DCK7JP26.js","/cdn/shopifycloud/checkout-web/assets/c1/67e8c664.CnfdICyB.js","/cdn/shopifycloud/checkout-web/assets/c1/4bb32466.CsnrxvGj.js","/cdn/shopifycloud/checkout-web/assets/c1/ed37d3c3.DrqDwRix.js","/cdn/shopifycloud/checkout-web/assets/c1/30df5a02.DpDIgG7M.js","/cdn/shopifycloud/checkout-web/assets/c1/e32a8416.DCUKucq9.js","/cdn/shopifycloud/checkout-web/assets/c1/eb0f242a.DWYM7CpL.js","/cdn/shopifycloud/checkout-web/assets/c1/109c16d9.Dz8F0ODV.js","/cdn/shopifycloud/checkout-web/assets/c1/35fb5eb6.jWlr_cup.js","/cdn/shopifycloud/checkout-web/assets/c1/05f561d4.DbsavZdT.js","/cdn/shopifycloud/checkout-web/assets/c1/69f8f26d.B9X3pmOb.js"];
      var styles = ["/cdn/shopifycloud/checkout-web/assets/c1/assets/app.CGRs8DQS.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/deferred-boot.HEpal1XU.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/OnePage.mSY95ESL.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/256cc32287.B1YSPUDc.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/a50c8864f4.COdDyHmf.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/7188aae948xccd7bc85.Bi1nHaU-.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/90ea855f49.uZEuHncj.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/69c8bed031.BEvzDDvy.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/fed0657f2bxc9b4d095.CuRoM9zv.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/6e3faf45e1.Du9dByaI.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/6e3faf45e1x0e0212c9.ct4xfivv.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/c0d88fcb7bxbaeb52f9.BAjucZ-8.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/f409e9cd1fx9f0ef4a6.B0RErzdh.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/621ec27e44.B5DPTpH4.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/5caf6ce603.87JMHPUK.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/de4d443464.DPEapfiO.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/966e3f4d79.gzvCNwz_.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/d4951797f3.CtjKurIY.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/df684aa9a8.Cl3P6dqs.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/f2a87b867b.Cl0Eyn3N.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/4d60858badxb036935a.xO_7ctnq.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/65db0eadda.qa_ACxP4.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/5a34f22f1a.D7MQTDGO.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/e8404cbaefx27591707.B68J3GgF.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/7aa3c6599b.C5b9n-0_.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/e07f74760d.DU0m5rdF.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/e07f74760dxbaeb52f9.skObByU9.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/6559bc5a39x1573b800.vTcdVGq4.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/89f3b0bff6.D7Ujmshx.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/500596e378xe1c30c9c.CyQZvZOO.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/bde15ff106x11e90a44.t4ylkATc.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/04e578408ax11e90a44.KhTiKgPS.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/04e578408ax6d8a6990.DpLOWYa8.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/d34ebf45edx11e90a44.btyKOfco.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/81ca749d51x11e90a44.DrWvAMMF.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/d455ee2f96x11e90a44.B0R8BMTd.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/d455ee2f96x670d76d4.BbxB_6wt.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/d455ee2f96x03fe6ed3.CVKcAbIN.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/d455ee2f96xd17a0c7b.BULdn7yC.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/343ea67e0bx11e90a44.s-Kd_X2E.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/401ac968b4x11e90a44.JBO5WNhc.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/81ca749d51.DRJckcGa.css"];
      var fontPreconnectUrls = [];
      var fontPrefetchUrls = [];
      var imgPrefetchUrls = ["https://cdn.shopify.com/s/files/1/0552/7991/1076/files/clogo_540c9c84-db36-46fe-8dbb-e512d29d5c11_x320.png?v=1699250205"];

      function preconnect(url, callback) {
        var link = document.createElement('link');
        link.rel = 'dns-prefetch preconnect';
        link.href = url;
        link.crossOrigin = '';
        link.onload = link.onerror = callback;
        document.head.appendChild(link);
      }

      function preconnectAssets() {
        var resources = preconnectOrigins.concat(fontPreconnectUrls);
        var index = 0;
        (function next() {
          var res = resources[index++];
          if (res) preconnect(res, next);
        })();
      }

      function prefetch(url, as, callback) {
        var link = document.createElement('link');
        if (link.relList.supports('prefetch')) {
          link.rel = 'prefetch';
          link.fetchPriority = 'low';
          link.as = as;
          if (as === 'font') link.type = 'font/woff2';
          link.href = url;
          link.crossOrigin = '';
          link.onload = link.onerror = callback;
          document.head.appendChild(link);
        } else {
          var xhr = new XMLHttpRequest();
          xhr.open('GET', url, true);
          xhr.onloadend = callback;
          xhr.send();
        }
      }

      function prefetchAssets() {
        var resources = [].concat(
          scripts.map(function(url) { return [url, 'script']; }),
          styles.map(function(url) { return [url, 'style']; }),
          fontPrefetchUrls.map(function(url) { return [url, 'font']; }),
          imgPrefetchUrls.map(function(url) { return [url, 'image']; })
        );
        var index = 0;
        function run() {
          var res = resources[index++];
          if (res) prefetch(res[0], res[1], next);
        }
        var next = (self.requestIdleCallback || setTimeout).bind(self, run);
        next();
      }

      function onLoaded() {
        try {
          if (parseFloat(navigator.connection.effectiveType) > 2 && !navigator.connection.saveData) {
            preconnectAssets();
            prefetchAssets();
          }
        } catch (e) {}
      }

      if (document.readyState === 'complete') {
        onLoaded();
      } else {
        addEventListener('load', onLoaded);
      }
    })();
  