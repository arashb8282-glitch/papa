import{n as e}from"./vite-component-manager.modern-DoPsXBrr.js";import{t}from"./vite-focus-trap.esm-CqXp1QdT.js";var n=class extends HTMLElement{searchInput=null;resultsContainer=null;debounceTimer=null;$trapInner=null;focusTrap=null;_closedByTogglerClick=!1;constructor(){super()}connectedCallback(){this.initializeElements(),this.initializeFocusTrap(),this.bindEvents()}disconnectedCallback(){this.searchInput&&this.searchInput.removeEventListener(`input`,this.handleInput)}initializeFocusTrap(){this.$trapInner=this.querySelector(`[data-predictive-search-form]`),this.focusTrap=t(Array.from([this.$trapInner]),{checkCanFocusTrap:e=>{let t=e.map(e=>new Promise(t=>{let n=setInterval(()=>{getComputedStyle(e).visibility!==`hidden`&&(t(),clearInterval(n))},5)}));return Promise.all(t).then(()=>{})},onActivate:this.show,onDeactivate:this.hide,clickOutsideDeactivates:e=>{let t=e.target;return document.querySelector(`[data-search-toggler]`)?.contains(t)&&(this._closedByTogglerClick=!0),!0}})}initializeElements(){this.searchInput=this.querySelector(`input[type="text"]`),this.resultsContainer=this.querySelector(`[data-predictive-search-results]`)}bindEvents(){this.searchInput&&this.searchInput.addEventListener(`input`,this.handleInput)}handleInput=e=>{let t=e.target.value.trim();if(this.debounceTimer&&clearTimeout(this.debounceTimer),t.length<2){this.hideResults();return}this.debounceTimer=setTimeout(()=>{this.performSearch(t)},300)};async performSearch(e){try{let t=await(await fetch(`${window.Shopify?.routes?.root}search/suggest.json?q=${encodeURIComponent(e)}&resources[type]=product&resources[limit]=5&resources[options][unavailable_products]=hide&resources[options][fields]=title,product_type,variants.title,vendor,body&resources[options][count]=true`)).json(),n=[];t.resources&&t.resources.results&&t.resources.results.products&&(n=t.resources.results.products),this.renderResults(n)}catch(e){console.error(`Search error:`,e)}}renderResults(e){if(!this.resultsContainer)return;if(e.length===0){let e=this.getAttribute(`data-no-results-label`)||`No results`,t=this.searchInput?.value.trim()||``,n=`
                <div class="text-label p-unit-sm">${e.replace(`{{ query }}`,t)}</div>
            `;this.resultsContainer.innerHTML=n,this.showResults();return}let t=this.getAttribute(`data-results-label`)||`Results`,n=this.getAttribute(`data-view-all-label`)||`View all results`,r=this.searchInput?.value.trim()||``,i=e.length===5,a=`
            <div class="text-label p-unit-sm">${t}</div>
            ${e.map(e=>`
                <a href="${e.url}" class="flex gap-2 p-unit-sm not-last:border-b not-last:border-b-gray group">
                    <div class="w-[50px] aspect-5/7 bg-gray rounded-sm overflow-hidden">
                        ${e.featured_image?`<img src="${e.featured_image.url}" class="object-cover h-full w-full" width="50" height="70" loading="lazy" alt="${e.featured_image.alt}">`:`<div class="w-[50px] aspect-5/7 bg-gray rounded-sm"></div>`}
                    </div>
                    <div class="flex-1 min-w-0">
                        <span class="text-label block group-hover:underline">${e.title}</span>
                    </div>
                </a>
            `).join(``)}
            ${i?`
            <div class="p-unit-sm">
                <a href="${window.Shopify?.routes?.root}search?q=${encodeURIComponent(r)}" class="c-button button-fluid">
                    <span class="c-button_label">
                        <span class="c-button_label_inner">${n}</span>
                    </span>
                </a>
            </div>
            `:``}
        `;this.resultsContainer.innerHTML=a,this.showResults()}showResults(){this.resultsContainer&&this.resultsContainer.classList.remove(`hidden`)}hideResults(){this.resultsContainer&&this.resultsContainer.classList.add(`hidden`)}show=()=>{this.classList.add(`show-modal`),document.dispatchEvent(new CustomEvent(`predictive-search:open`))};hide=()=>{this.classList.remove(`show-modal`),this.hideResults()};toggle(){if(this._closedByTogglerClick){this._closedByTogglerClick=!1;return}this.focusTrap?.active?this.deactivate():this.activate()}activate(){this.focusTrap?.activate()}deactivate(){this.focusTrap?.deactivate()}};customElements.define(`c-predictive-search`,e(n,`PredictiveSearch`));