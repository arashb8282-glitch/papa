importScripts('https://estudioniksen.com/cdn/wpm/s43600932w1bbca933p2f8a9c65m024fd2f2m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('1862926581', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-1862926581@6c9b18e5cfd1870efdf1e745ae1f8553.js');
