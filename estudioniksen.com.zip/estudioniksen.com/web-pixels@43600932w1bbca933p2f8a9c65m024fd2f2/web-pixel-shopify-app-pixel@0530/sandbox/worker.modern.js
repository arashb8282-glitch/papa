importScripts('https://estudioniksen.com/cdn/wpm/s43600932w1bbca933p2f8a9c65m024fd2f2m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('shopify-app-pixel', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-shopify-app-pixel@0530.js');
