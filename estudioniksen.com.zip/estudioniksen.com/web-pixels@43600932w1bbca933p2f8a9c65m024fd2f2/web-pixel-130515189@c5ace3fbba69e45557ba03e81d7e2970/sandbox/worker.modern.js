importScripts('https://estudioniksen.com/cdn/wpm/s43600932w1bbca933p2f8a9c65m024fd2f2m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('130515189', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-130515189@c5ace3fbba69e45557ba03e81d7e2970.js');
