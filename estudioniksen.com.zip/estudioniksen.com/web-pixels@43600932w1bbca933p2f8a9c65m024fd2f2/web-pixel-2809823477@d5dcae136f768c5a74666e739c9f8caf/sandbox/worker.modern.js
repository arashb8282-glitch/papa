importScripts('https://estudioniksen.com/cdn/wpm/s43600932w1bbca933p2f8a9c65m024fd2f2m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('2809823477', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-2809823477@d5dcae136f768c5a74666e739c9f8caf.js');
